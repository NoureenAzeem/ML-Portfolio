import streamlit as st
import joblib
import re

# Load model and vectorizer
model = joblib.load('logistic_model.pkl')
vectorizer = joblib.load('tfidf_vectorizer.pkl')

st.title("Fake News Detector")
st.write("Paste a news article below and check if it's Fake or Real.")

text_input = st.text_area("Enter news text here")

if st.button("Check"):
    cleaned_text = re.sub(r'[^a-zA-Z]', ' ', text_input).lower()
    vectorized_text = vectorizer.transform([cleaned_text])
    prediction = model.predict(vectorized_text)[0]
    confidence = model.predict_proba(vectorized_text).max()
    st.write(f"Prediction: **{prediction}**")
    st.write(f"Confidence: {confidence*100:.2f}%")
