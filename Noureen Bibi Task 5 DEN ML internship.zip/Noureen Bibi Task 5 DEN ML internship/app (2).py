
import streamlit as st
import joblib
import nltk
import re
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords

stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()

def preprocess(text):
    text = text.lower()
    text = re.sub(r'[^a-z ]', '', text)
    tokens = nltk.word_tokenize(text)
    tokens = [lemmatizer.lemmatize(w) for w in tokens if w not in stop_words]
    return ' '.join(tokens)

st.title("Text Classification App")
model = joblib.load('model.pkl')
vectorizer = joblib.load('vectorizer.pkl')

user_input = st.text_area("Enter text for classification:")
if st.button("Predict"):
    clean_text = preprocess(user_input)
    vec = vectorizer.transform([clean_text])
    prediction = model.predict(vec)[0]
    st.write(f"Prediction: **{prediction}**")
