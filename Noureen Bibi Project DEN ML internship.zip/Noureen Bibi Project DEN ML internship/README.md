# Fake News Detector

## Overview
This project detects whether a news article is Fake or Real using NLP techniques and Logistic Regression.

## Files
- `Fake_News_Detector.ipynb` - Jupyter Notebook with full pipeline
- `app.py` - Streamlit web app
- `requirements.txt` - Project dependencies
- `README.md` - Project overview

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Train the model using the notebook.
3. Run the app: `streamlit run app.py`
