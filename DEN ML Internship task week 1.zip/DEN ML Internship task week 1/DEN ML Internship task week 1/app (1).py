import streamlit as st
import numpy as np
import joblib

# Load saved model and scaler
model = joblib.load('logistic_regression_model.pkl')
scaler = joblib.load('scaler.pkl')

st.title("❤️ Heart Disease Prediction App")

st.write("""
This app predicts the likelihood of heart disease based on patient information.
""")

# User Inputs
age = st.number_input('Age', min_value=1, max_value=120, value=50)
sex_display = st.selectbox('Sex', ['Female', 'Male'])
sex = 1 if sex_display == 'Male' else 0
cp = st.slider('Chest Pain Type (cp)', 0, 3, 0)
trestbps = st.number_input('Resting Blood Pressure', 80, 200, 120)
restecg = st.slider('Resting ECG', 0, 2, 0)
thalach = st.number_input('Max Heart Rate Achieved', 60, 220, 150)
exang = st.selectbox('Exercise Induced Angina', [0,1])
oldpeak = st.number_input('ST depression', 0.0, 6.0, 1.0)
slope = st.slider('Slope of peak exercise ST', 0, 2, 1)
ca = st.slider('Number of major vessels', 0, 3, 0)
thal = st.slider('Thalassemia', 0, 3, 1)

if st.button("Predict"):
    # Create feature array
    features = np.array([[age, sex, cp, trestbps,
                           restecg, thalach, exang, oldpeak,
                           slope, ca, thal]])
    # Scale features
    features_scaled = scaler.transform(features)
    # Predict
    prediction = model.predict(features_scaled)

    if prediction[0] == 1:
        st.error("⚠️ High likelihood of Heart Disease")
    else:
        st.success("✅ Low likelihood of Heart Disease")
