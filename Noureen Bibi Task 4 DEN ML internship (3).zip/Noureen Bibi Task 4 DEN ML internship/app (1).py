import streamlit as st
import numpy as np
import pandas as pd
import joblib

st.title('🧠 Breast Cancer Classification — With vs Without Feature Selection')

st.write('This demo loads two pre-trained pipelines and lets you compare predictions.')

# Load models
without = joblib.load('model_without_fs.pkl')
withfs = joblib.load('model_with_fs.pkl')
pipe_without = without['pipeline']
pipe_withfs = withfs['pipeline']
all_features = without['feature_names']
selected_features = withfs.get('selected_features', all_features)

# User picks which model to use
choice = st.radio('Choose model:', ['Without Optimization (All features)', 'With Optimization (Selected features)'])

st.markdown('---')

# Build input form for all features (pipeline will internally select if needed)
with st.form('inputs'):
    cols = st.columns(3)
    vals = {}
    for i, f in enumerate(all_features):
        with cols[i % 3]:
            vals[f] = st.number_input(f, value=0.0, format='%f')
    submitted = st.form_submit_button('Predict')


if submitted:

    X = pd.DataFrame([vals], columns=all_features)

    if choice.startswith('Without'):

        proba = pipe_without.predict_proba(X)[0]

        pred = int(np.argmax(proba))

    else:

        proba = pipe_withfs.predict_proba(X)[0]

        pred = int(np.argmax(proba))

    st.success(f'Prediction: {pred} (0=malignant, 1=benign)')

    st.write('Probability (class 0, class 1):', np.round(proba, 4))

